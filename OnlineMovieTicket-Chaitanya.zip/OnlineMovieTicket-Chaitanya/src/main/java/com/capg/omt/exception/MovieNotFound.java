package com.capg.omt.exception;

public class MovieNotFound extends RuntimeException {

	public MovieNotFound(String message) {
		super(message);
	}
}
