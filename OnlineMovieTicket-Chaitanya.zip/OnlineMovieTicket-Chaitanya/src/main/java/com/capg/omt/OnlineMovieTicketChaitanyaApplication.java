package com.capg.omt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineMovieTicketChaitanyaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineMovieTicketChaitanyaApplication.class, args);
		System.out.println("Application Started");
	}

}
